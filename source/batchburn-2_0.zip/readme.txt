BatchBurn 2.00 for OS/2               Martin Vieregg, Germany
Freeware                              M a r t i n at hypermake.de
                                      January 2005

Homepage:
http://www.hypermake.com


BatchBurn is a set of Freeware batch files for using the Freeware
commandline programs CDRECORD and MKISOFS to burn CD-ROMs.

***Introduction***

CDRECORD is a very good CD writing software, but tedious to use.
I used it for several years but always forgot the commands. Then I
wrote batch files, but forgot how to use the batchfiles. Now these
batchfiles are really simple to use -- and there's no excuse for
forgetting the usage anymore: just type CDHELP.

In the current version, I've added commands to burn Audio CDs
and to create MP3 files (type CDAHELP).

BatchBurn does not use REXX; instead, several batch files use
the commandline program DO.EXE which can also be used separately:
DO without parameters shows a help screen.

***How to get CDrecord***

To get the CDrecord main program, visit the Hobbes download page
http://hobbes.nmsu.edu/cgi-bin/h-browse?dir=//pub/os2/apps/mmedia/cd/cd-r

The current CDrecord is version 2.00:
http://hobbes.nmsu.edu/pub/os2/apps/mmedia/cd/cd-r/cdrecord-2_00_os2.zip

***Installation***

CDRECORD must be installed. Make sure that the directories where 
cdrecord.exe and mkisofs.exe reside are in the PATH statement in
your Config.sys.

Unpack the BatchBurn archive file to a new directory of your choice. Add 
the directory where the BatchBurn command files are located to your PATH 
statement. (edit the file [X]:\CONFIG.SYS, line "PATH=")

For long filename support, make sure that the CD driver statement in 
your config.sys includes the /W option:
IFS=C:\OS2\BOOT\CDFS.IFS /W

The commandline program DO.EXE needs EMX.
If you have not the EMX library yet, please visit
ftp://ftp-os2.nmsu.edu/pub/os2/dev/emx/v0.9d
or
http://hobbes.nmsu.edu/cgi-bin/h-browse?sh=1&dir=/pub/os2/dev/emx/v0.9d

(KBDVIO32.DLL is no more necessary.)

If you are not sure if EMX is installed, simply type DO. If DO is running
(showing help screen), it is OK, otherwise not...

Now reboot your system.


***First steps***

Type CDHELP to get a command overview. Then run CDINIT. One editor 
window will show the free disk space on your drives, and the address
of your CD Writer. The other editor (sometimes exactly below the first
editor window) shows the file cdset.cmd and allows you to change your
user-specific settings. The file is self-explanatory.

All commands besides CDZIP and CDZIPX are used without parameters.

To use the commands CDZIP and CDZIPX, you need to have Info-Zip
(Zip.exe) installed.

***How to burn a DATA CD***

1. After the "first steps", simply copy all the files you want to burn to
   the CD_BURNDIR directory you defined while running CDINIT.

   Enter "CDSPACE" to control the size of the data.

   Zipping the files may be preferable to copying them, since zipping
   preserves the extended attributes. To zip your files, open a command
   window and change to the directory you wish to save and then type 
   CDZIP or CDZIPX. Use CDZIPX if you wish to exclude some specific file
   extensions from the CD. (Edit CDZIPX.CMD to choose file extensions to 
   exclude. The selected extensions in the included example are for
   Borland C and Sibyl programming).

2. Creating an image file: 
   Type CDFIRST if you want to burn an empty CD or type CDADD if you
   want to add data to an already existing CD. (Make sure that you have
   enough space on the CD!) CDFIRST always writes "multisession" CDs, so
   you can later add data with CDADD. When using CDADD, the CD to which
   the data is to be added must be in the CD drive.
   
   If you want to burn a single directory, it is not necessary to copy all
   files to your CD_BURNDIR directory. Instead, you can enter a specific
   directory name.
   [C:\] CDFIRSTDIR D:\MyDir
   [C:\] CDADDDIR D:\MyDir
   The name "MyDir" won't appear on the CD. Instead, the subdirectories of
   "MyDir" will appear in the root directory of the CD.

   If you use CDADD or CDADDDIR, the CD must be in your CD drive already,
   since CDRECORD needs to analyze the current data end position.

3. To burn the CD, simply type CDREC. When the burning process is 
   finished, the CD will be ejected.
   
Instead of copying the files to the CD_BURNDIR directory, you can
also ZIP the files. The following commands require the commandline
program ZIP.EXE (Info-Zip).

[C:\MYDIR] CDZIP MyDir_01_2005

creates a Zip file MyDir_01_2005.zip in the CD_BURNDIR directory.
That means this zip file will be placed in the root directory of the CD.

If you type CDZIPX instead of CDZIP, files with a specific file extension
are excluded in the Zip file. To see the list of file extensions, please
open CDZIPX.CMD in an editor and edit the file for your own purpose.


BatchBurn always writes an image file. It does not support burning data
on the fly. But you can concatenate the commands for making an image and 
burning the disc:

cdFirstRec
   runs CDFIRST and CDREC one after another  
cdAddRec
   runs CDADD and CDREC one after another  


CDOPEN opens the tray of the CD drive,
CDCLOSE closes the tray.

Both commands wait for finishing the process. For the CDCLOSE command
that means you get the command prompt back after you have really access
to the CD drive.


*** HOW TO BURN AN AUDIO CD ***

type CDAHELP and follow the instructions! You need to have 1,5 GB
free disk space to burn 80min data CDs. I don't know why 750 MB is not
sufficient, but CDRECORD created an error if there was not enough
free space in the current directory. Here's the help when typing CDAHELP:

1. make an empty directory current                                  
2. make sure that no AUDIO_*.WAV files are in the current directory,
   because they are deleted without warning by CDAREAD              
3. place the source CD into the CD drive (same drive as burning)    
4. type CDAREAD and wait until the drive opens automatically        
5. place a new empty CD into the CD drive                           
6. type CDAWRITE and wait until the drive opens automatically       
7. continue with step 5 if you want to make several copies          


*** HOW TO CREATE MP3 FILES FROM AN AUDIO CD ***

Download the most current version of Gogo from hobbes.nmsu.edu:
http://hobbes.nmsu.edu/pub/os2/apps/mmedia/sound/convert/gogo-3.13-emx.zip
and copy gogo.exe into a directory which is part of the PATH statement. 

If you want a different bit rate from 128, edit the number "128"
in the batch file CDGOGO.CMD. If you are more ambitious in quality, 
192 should be a good choice. Then do the following:

1. make an empty directory current
2. make sure that no AUDIO_*.WAV files are in the current directory,
   because they are deleted without warning by CDAREAD
3. Run CDAREAD or CDAREAD2 to get WAV files from the Audio CD
4. Simply run CDGOGO to convert all WAV files which are located
   in the current directory and in its subdirectories. MP3 files
   which do already exist are overwritten.

"GOGO" is LAME-based, but 3 times faster than "LAME" and 4 times
faster than "BLADEENC"; I have made no quality checks yet.
GOGO supports processor enhancements like "3DNOW". CDGOGO.CMD solves
two problems you will have if you run GOGO alone: First, the priority 
is very high so you can't really work anymore with your computer while
encoding. Second, you have to execute GOGO for every file.
These two problems are solved by CDGOGO, thanks to SPE.EXE and DO.EXE.

If you execute CDGOGO, the size of all WAV files is shown at the
beginning. If you have got a 1 GHz processor, GOGO should compile
approximately 100 MB WAV files per minute, and a 3 GHz processor
300 MB per minute. So the size will help you estimating the amount
of time for encoding. If your computer is located in your bedroom,
then edit CDGOGO.CMD and delete the "sound" line which plays a sound
after encoding all WAV files.
   

It is useful to enlarge the OS/2 command window to see more results:

[C:\] mode 80,102


***fixed bugs***

In Version 1.00, CDFIRSTREC CDADDREC failed because of a missing hyphen
before "gracetime".
In Version 1.01, a short gracetime can corrupt the CD's; gracetime is
now eliminated.

In 1.03, I have fixed two bugs in cdinit.cmd: cdinit failed if a FAT drive
was current (because of 8.3 limitation); then "do which cdset" produced
a malfunction, now replaced by "do whichfirst cdset" (also do.exe has been
changed for this functionality.)


***Other programs in this package***

The batch files uses three EXE files:

Delpath.exe  a Freeware program for deleting whole directories, see 
             Delpath.txt
Do.exe       a Freeware program which I have written with various 
             functionalities. Do.exe requires EMX.
             For an overview, simply type DO without parameters,
             for more information, see DO.TXT
Spe.exe      let you set the priority of a program, see SPE.TXT,
             used by CDGOGO.CMD

Do.exe replaces a handful of old Freeware exe programs which do not
run properly anymore because of integer overflow. Do.exe also works
if the results are larger than 32 bits, e.g. free disk space larger
than 4 GB. I have written do.exe with Sibyl (Pascal). If you would
like to see any functions added, please send me your suggestions.


***Problems***

If you have problems while writing CDs, it can be useful to enlarge
the priority of CDRECORD. In this case, edit CDREC.CMD
and prefix the string "spe t28" before "cdrecord":

spe t28 cdrecord -multi -eject ...


Have fun!

Send comments to M a r t i n at Hypermake.de